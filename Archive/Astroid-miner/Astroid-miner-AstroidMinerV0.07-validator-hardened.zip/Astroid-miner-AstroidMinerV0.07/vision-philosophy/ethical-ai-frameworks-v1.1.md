# Ethical Framework v1.1 — Historical Delta (Merged)

**Status:** Historical. The content of this delta has been merged into the authoritative document:

→ [`ethical-ai-frameworks.md`](ethical-ai-frameworks.md) (v1.1 consolidated)

Do not treat this file as current policy. It is retained only for provenance and change-history.

---

## What this delta originally recorded (January 2026)

Clarifications and upgrades from the v1.0 base that are now integrated into the consolidated document:

1. **Separation of roles** — Scoop/extraction vs transport/logistics; no single-unit end-to-end autonomy.
2. **Tested Framework First** — Ethical safeguards must be testable, observable, or measurable (sensor / threshold / reversible action).
3. **Runaway & rogue management** — Replication gating, failure containment, graceful degradation under partial failure.
4. **Anonymity & location agnosticism** — Ethics defined by behavioral constraints, not named locations or bodies.
5. **Auditability** — Ethically significant decisions must be logged, reconstructable, and interpretable post-hoc.
6. **Explicit non-goals** — Not profit optimization, not scarcity exploitation, not unbounded moral philosophy.

The original delta also stated backward compatibility with v1.0 concepts and incompatibility with architectures that allow single-unit end-to-end autonomy, rely on unverifiable intent language, or cannot be tested under failure conditions. Those statements remain in force in the consolidated document.

---

**Merged:** August 2026  
**Canonical document:** `vision-philosophy/ethical-ai-frameworks.md`
