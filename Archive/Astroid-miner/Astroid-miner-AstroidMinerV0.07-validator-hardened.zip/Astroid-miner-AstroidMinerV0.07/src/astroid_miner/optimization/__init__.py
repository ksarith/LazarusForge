"""
Astroid-miner optimization — public API (MDL-OPT-01).
"""

from astroid_miner.optimization.optimizer import optimize_mass_allocation

__all__ = [
    "optimize_mass_allocation",
]
